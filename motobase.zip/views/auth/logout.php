<?php
    controller("Auth");
    $auth = new Auth();
    $auth->logout();
?>