<?php
error_reporting(0);
require('config.php');
require('headers.php');
require('functions.php');
require('routes.php');

