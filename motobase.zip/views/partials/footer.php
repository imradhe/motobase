<h4 class="footer mt-5">
  Developed By
  <a rel="noopener" href="https://imradhe.netlify.app" target="_blank" style="text-decoration: none;">
    Radhe Shyam Salopanthula
  </a>
</h4>